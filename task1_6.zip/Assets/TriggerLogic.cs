using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TriggerLogic : MonoBehaviour
{
    public Vector3 force;
    public string TriggerName;
    public bool NulifyVelocity;
    // Start is called before the first frame update
    private void OnTriggerEnter(Collider other)
    {
        Debug.Log($"{other.name} has entered the {TriggerName} trigger zone!");
        Rigidbody rb = other.GetComponent<Rigidbody>();

        if (NulifyVelocity)
        {
            rb.velocity = new Vector3(0, 0, 0);
        }
        rb.AddForce(force, ForceMode.VelocityChange);
    }
}
