using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FragmentBehaviour : MonoBehaviour
{
    // Start is called before the first frame update

    public Vector3 Direction;
    public Rigidbody Rigidbody;
    // Update is called once per frame
    void Start()
    {
        Rigidbody.AddForce(Direction, ForceMode.Impulse);
    }
}
