using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Cannonball : MonoBehaviour
{

    public Rigidbody body;
    public Vector3 vector3;
    // Start is called before the first frame update
    void Start()
    {
        body.AddForce(vector3, ForceMode.Impulse);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
