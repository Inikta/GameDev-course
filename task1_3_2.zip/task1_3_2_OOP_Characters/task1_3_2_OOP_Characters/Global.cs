﻿namespace task1_3_2_OOP_Characters
{
    public enum Sex {MAN, WOMAN}
}
